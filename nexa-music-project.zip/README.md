# NEXA MUSIC

Website library musik berbasis HTML, CSS, dan JavaScript Vanilla. Mendukung:
- File audio lokal (diputar langsung).
- Penyimpanan tautan playlist Spotify dan YouTube/YouTube Music.
- Embed playlist Spotify dan YouTube.
- Import metadata playlist dan pencarian melalui Spotify Web API dan YouTube Data API v3.
- Library sederhana menggunakan localStorage.

## 1. Jalankan lokal
Gunakan server lokal, jangan membuka `index.html` langsung karena JavaScript memakai ES Modules dan OAuth redirect.
Contoh VS Code: pasang ekstensi Live Server lalu klik kanan `index.html` > Open with Live Server.
Redirect default contoh: `http://127.0.0.1:5500/`.

## 2. Konfigurasi
Salin `js/config.example.js` menjadi `js/config.js`, lalu isi:
- Spotify Client ID dari Spotify Developer Dashboard.
- YouTube Data API v3 key dari Google Cloud Console.
- Spotify Redirect URI yang sama persis dengan URL lokal.

Ubah `js/app.js` agar import config dari `./config.js` (sudah demikian). File `config.js` sengaja tidak disertakan agar kredensial tetap milik pemilik proyek.

## 3. Spotify
1. Buat aplikasi di Spotify Developer Dashboard.
2. Tambahkan Redirect URI persis, misalnya `http://127.0.0.1:5500/`.
3. Salin Client ID ke config.js.
4. Pastikan aplikasi memenuhi aturan Spotify Developer Mode dan persyaratan akun/pengguna yang berlaku.
5. Login saat pencarian Spotify; otorisasi memakai Authorization Code with PKCE.
6. Jangan pernah menaruh Client Secret di frontend. Untuk aplikasi produksi, gunakan backend untuk pengelolaan token dan kebijakan API.

Catatan: akses playlist/endpoint Spotify dapat dibatasi oleh mode aplikasi, jenis akun, kuota, persyaratan platform, dan perubahan kebijakan Spotify. Jika endpoint playlist tidak tersedia bagi aplikasi, embed tetap bisa digunakan untuk mendengarkan melalui Spotify.

## 4. YouTube
1. Buat project di Google Cloud Console.
2. Aktifkan YouTube Data API v3.
3. Buat API key dan batasi berdasarkan HTTP referrer serta API.
4. Isi key di config.js.
5. Import metadata hanya untuk playlist yang dapat diakses oleh API. Playlist privat atau dibatasi tidak bisa dibaca menggunakan API key publik.

## 5. Batasan penting
- Spotify Embed dan YouTube iframe memutar konten pada pemutar resmi masing-masing; NEXA tidak mengambil audio dari layanan tersebut.
- API YouTube Data mengambil metadata, bukan file audio.
- Spotify Web API mengambil metadata, bukan stream audio bebas.
- File lokal diputar melalui HTML Audio API.
- Jangan mengunduh, menyalin, atau mendistribusikan audio tanpa hak/izin.
- Data library disimpan di localStorage browser. File audio lokal yang dipilih menggunakan object URL dan perlu dipilih ulang setelah halaman dimuat ulang.
- Untuk sinkronisasi lintas perangkat, multiuser, dan penyimpanan permanen, tambahkan backend dan database.

## 6. Deploy
Untuk GitHub Pages, unggah seluruh folder ke repository. Daftarkan URL HTTPS GitHub Pages sebagai Spotify Redirect URI. Jangan menyimpan API key yang tidak dibatasi di repository publik. Untuk proyek penelitian, dokumentasikan tanggal akses, API, batasan akses, dan persetujuan pengguna.
